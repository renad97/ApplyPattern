package hajjreservationsystem;

public class paymentAdapter implements paymentInterface {

    Payment pay ;

    public paymentAdapter (Payment payment)
    {
        pay = payment;
    }

    public void setCvvAdapter (int cvv)
    {
        pay.setCvv(cvv);
    }

    public void setCardHolderFullNameAdapter(String holderName)
    {
        pay.setCardHolderFullName(holderName);
    }

    public void setCardNumberAdapter(String cardNumber) {
        pay.setCardNumber(cardNumber);
    }

    public void setpaymentMethodAdapter()
    {
        pay.setpaymentMethod();
    }

}
