package hajjreservationsystem;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Scanner;

/**
 *
 * @author ragha
 */
//This is the thired class, it has the vaccine information
public class Vaccine extends Observer {

    //Fields
    private boolean vaccinate;
    private int numberOfDoses;
    private int vaccineName;
    DonationSubject donation; //for observer consructr
    int vaccineChoice;

    Scanner scan = new Scanner (System.in);

    public Vaccine (boolean vaccinate, int vaccineChoice, int numberOfDoses, int vaccineName)
    {
        this.vaccinate = vaccinate;
        this.vaccineChoice = vaccineChoice;
        this.numberOfDoses = numberOfDoses;
        this.vaccineName = vaccineName;
    }

    public Vaccine ()
    {
        vaccinate = true;
        vaccineChoice = 0;
        numberOfDoses = 0;
        vaccineName = 0;
    }

    //consractur for observer
    public Vaccine (DonationSubject donation)
    {
        this.donation = donation;
        this.donation.attach(this);
    }

    //1) declread a static singleton
    private static Vaccine instance = null;

    //2) create static getInstance()
    public static Vaccine getInstance()
    {
        if (instance==null)
        {
            instance = new Vaccine();
        }
        // return
        return instance;
    }

    public void setVaccinate(boolean vaccine)
    {
        vaccineChoice= scan.nextInt();
        scan.nextLine();

        if(vaccineChoice == 1)
        {
            vaccine = true;
        }
        else if(vaccineChoice == 2)
        {
            vaccine = false;
        }
        else
        {
            while(vaccineChoice != 1 && vaccineChoice!=2)
            {
                System.out.println("Wrong input");
                System.out.print("Try again: ");
                vaccineChoice = scan.nextInt();
            }
        }
        this.vaccinate = vaccine;
    }

    public String isVaccinate()
    {
        if(vaccinate == true)
            return "Vaccinated";
        else
            return "NOT vaccinated";
    }

    public int getVaccineChoice()
    {
        return vaccineChoice;
    }

    public void setNumberOfDoses(int numberOfDoses)
    {

        try{
            numberOfDoses = scan.nextInt();
            scan.nextLine();
            this.numberOfDoses = numberOfDoses;

            while(numberOfDoses != 1 && numberOfDoses != 2 && numberOfDoses != 3)
            {
                System.out.print("Your choice is invalid, The minimum is 1 and the maximum is 3 "
                        + "please try again: ");
                numberOfDoses = scan.nextInt();
                scan.nextLine();
            }

        }
        catch(Exception e){
            System.out.println("enter the number ");

        }
    }

    public int getNumberOfDoses()
    {
        return numberOfDoses;
    }

    public void setVaccineName(int vaccineName)
    {

        try{
            int vaccineChoice = scan.nextInt();
            scan.nextLine();

            while(vaccineChoice != 1 && vaccineChoice != 2)
            {
                System.out.print("Your choice is invalid, please try again: ");
                vaccineChoice = scan.nextInt();
                scan.nextLine();
            }
            vaccineName = vaccineChoice;

        }
        catch(Exception e){
            System.out.println("enter the number ");

        }
    }

    public String vaccineName()
    {
        if (vaccineName == 1)
        {
            return "Pfizer";
        }
        else
        {
            return "Astrazica";
        }
    }

    public String getVaccineName()
    {
        return vaccineName();
    }


    //String method returning all information of this class.
    public String toString()
    {
        String text = "\nYou are: " +isVaccinate()
                +"\nVaccine Name: "+getVaccineName()
                +"\nNumber Of Doses: "+getNumberOfDoses()+" Doses";
        return text;
    }

    //override method from observer
    @Override
    public void update() {
        System.out.println("Your money will be contributed to the vaccination.");

    }
}