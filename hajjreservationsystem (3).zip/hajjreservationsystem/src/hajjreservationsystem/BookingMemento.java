/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hajjreservationsystem;

/**
 *
 * @author ragha
 */
public class BookingMemento {
    
    private final String fullName;
    private final String country;
    private final String ID;
    private final boolean isResident;
    private final int age;
    private final int bookingNumber;

    public BookingMemento(String fullName, String country, String ID, boolean isResident, int age, int bookingNumber) {
        this.fullName = fullName;
        this.country = country;
        this.ID = ID;
        this.isResident = isResident;
        this.age = age;
        this.bookingNumber = bookingNumber;
    }

    public String getFullName() {
        return fullName;
    }

    public String getCountry() {
        return country;
    }

    public String getID() {
        return ID;
    }

    public boolean isResident() {
        return isResident;
    }

    public int getAge() {
        return age;
    }

    public int getBookingNumber() {
        return bookingNumber;
    }
    
}
