package hajjreservationsystem;

import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

//This is the first class. This class gathers the user's personal information.
public class Pilgrim extends Observer
{
    //Fields
    private boolean residentOrVisitor;
    private String fullName;
    private String country;
    private int age;
    private String iD;
    private int bookNum;

    DonationSubject donation; //for observer consructr
    Scanner scan = new Scanner (System.in);

    //Constructor that takes all arguments.
    public Pilgrim(boolean residentOrVisitor, String fullName, String country, int age, boolean vaccinate, String iD, int vaccineChoice, int bookNum) {
        this.residentOrVisitor = residentOrVisitor;
        this.fullName = fullName;
        this.country = country;
        this.age = age;
        this.iD = iD;
        this.bookNum = bookNum;
    }

    //Constructor that takes no arguments.
    public Pilgrim()
    {
        residentOrVisitor = true;
        fullName = "";
        country = "";
        age = 0;
        iD = "";
    }

    //consractur for observer
    public Pilgrim (DonationSubject donation)
    {
        this.donation = donation;
        this.donation.attach(this);
    }

    //This is a copy constructor, used in another class.
    public Pilgrim(Pilgrim personalInfo)
    {
        this.residentOrVisitor = personalInfo.residentOrVisitor;
        this.fullName = personalInfo.fullName;
        this.country = personalInfo.country;
        //this.age = personalInfo.age;
        this.iD = personalInfo.iD;
        this.bookNum = personalInfo.bookNum;
    }

    //1) declread a static singleton
    private static Pilgrim instance = null;

    //2) create static getInstance()
    public static Pilgrim getInstance()
    {
        if (instance==null)
        {
            instance = new Pilgrim();
        }
        // return
        return instance;
    }

    //Next are setters and getters
    public void setFullName(String fullName)
    {
        fullName = scan.nextLine();
        if (fullName.length()<3){
            System.out.println("enter the full name again:");
            setFullName(fullName);

        }
        this.fullName = fullName;

    }

    public String getFullName()
    {
        return fullName;
    }

    public void setCountry(String country)
    {
        country = scan.nextLine();
        if (country.length()<3){
            System.out.println("enter the country again:");
            setCountry(country);}
        this.country = country;

    }

    public String getCountry()
    {
        return country;
    }

    public void setID(String iD)
    {
        iD = scan.nextLine();
        if (iD.length()!=10){
            System.out.println("enter the ID again:");

            setID(iD);}
        else {
            for (int i = 0; i < iD.length(); i++) {
                if (!Character.isDigit(iD.charAt(i)) ){

                    System.out.println("Please all must be digit");
                    setID(iD);
                    break;
                }

            }

        }
        this.iD = iD;
    }

    public String getID()
    {
        return iD;
    }

    //isResident is a method that returns the user's choice as boolean, it is used in the setResidentOrVisitor method.
    public boolean isResident(int choice)
    {
        if(choice == 1)
        {
            return true;
        }

        else if(choice == 2)
        {
            return false;
        }

        else
        { //if chosen other than 1 or 2
            while(choice != 1 && choice!=2)
            {
                System.out.println("Wrong input");
                System.out.print("Try again: ");
                choice = scan.nextInt();
            }
        }
        return false;
    }

    public void setResidentOrVisitor(boolean residentOrVisitor)
    {
        int choice = scan.nextInt();
        //setting the isResident boolean value to the variable
        this.residentOrVisitor = isResident(choice);
    }

    public String getResidentOrVisitor()
    {
        if(residentOrVisitor == true){
            return "resident";
        }
        else
        {
            return "visitor";
        }
    }

    public void setAge(int age)
    {
        age = scan.nextInt();
        this.age = age;
    }

    public int getAge()
    {
        return age;
    }

    public int getBookNumber()
    {
        return bookNum;
    }

    public void setBookingNumber()
    {
        Random r = new Random();
        int number=r.nextInt(50000);
        bookNum = number;
    }

    //String method returning all information of this class.
    public String toString()
    {
        return "\nYour full name is: " +getFullName()+ "\nYou are a: "+getResidentOrVisitor()+"\nYour ID is: "+iD+"\nYou are from: "+country+
                "\nYour age is: "+getAge()+"\nYour booking number is: "+getBookNumber();
    }

    //override method from observer
    @Override
    public void update() 
    {
        System.out.println("Your money will be contributed to the purchase" +
                " of eid-alHajj clothes for the pilgrims.");
    }
    
    public BookingMemento createMemento() {
        return new BookingMemento(getFullName(), country, iD, residentOrVisitor, age, bookNum);
    }

    public void restoreMemento(BookingMemento memento) {
        this.fullName = memento.getFullName();
        this.country = memento.getCountry();
        this.iD = memento.getID();
        this.residentOrVisitor = memento.isResident();
        this.age = memento.getAge();
        this.bookNum = memento.getBookingNumber();
    }
    
}