/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hajjreservationsystem;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author ragha
 */
public class BookingCaretaker {
    
    ArrayList<BookingMemento> savedMemento = new ArrayList<BookingMemento>();

    public void saveMemento(BookingMemento memento) {
        savedMemento.add(memento);
    }

    public BookingMemento restoreMemento(int index) {
            return savedMemento.get(index);
    }
    
}
