package hajjreservationsystem;

public abstract class Observer {

    protected DonationSubject donation ;
    public abstract void update();
}
