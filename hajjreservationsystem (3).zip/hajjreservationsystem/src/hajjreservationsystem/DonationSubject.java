package hajjreservationsystem;
//import ObserverPattern.Listener.Observer;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DonationSubject {
    
    private List<Observer> observers = new ArrayList<Observer>();
    private int state;
    Scanner scan = new Scanner (System.in);

    public int getState() 
    {
        return state;
    }
    
    public void setState(int state) 
    {
        state = scan.nextInt();
        scan.nextLine();

        if (state == 1) 
        {
            notifyAllObservers();
        }
        
        else if(state == 2)
        {
            System.out.println("Thanke you.");
        }
        
        else
        {
            while(state != 1 && state!=2)
            {
                System.out.println("Wrong input");
                System.out.print("Try again: ");
                state = scan.nextInt();
                notifyAllObservers();
            }
        }
        this.state = state;
    }
    public void attach(Observer observer){
        observers.add(observer);
    }
    public void notifyAllObservers(){
        for (Observer observer : observers) {
            observer.update();
        }
    }
}