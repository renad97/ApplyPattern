package hajjreservationsystem;

public interface paymentInterface {

    public void setCvvAdapter(int cvv);

    public void setCardHolderFullNameAdapter(String holderName);

    public void setCardNumberAdapter(String cardNumber);

    public void setpaymentMethodAdapter();

}
